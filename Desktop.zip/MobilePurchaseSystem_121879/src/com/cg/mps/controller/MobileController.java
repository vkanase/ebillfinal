package com.cg.mps.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.mps.bean.Mobile;
import com.cg.mps.bean.PurchaseDetails;
import com.cg.mps.exception.MobileException;
import com.cg.mps.service.IMobileService;
import com.cg.mps.service.MobileServiceImpl;

@WebServlet(urlPatterns={"/home","/Buy","/Purchase"})
public class MobileController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

    public MobileController() 
    {
        super();
    }

	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	public void destroy()
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String path = request.getServletPath();
		String url ="" ;
		IMobileService mobileService = new MobileServiceImpl() ;
		System.out.println(path);
		
		try 
		{
			switch( path )
			{
				case "/home" :
					List<Mobile> mobiles = mobileService.getMobiles() ;
					request.setAttribute("mobileList", mobiles);
					url = "Home.jsp" ;
					System.out.println(mobiles);
					break ;
				
				case "/Buy" :
					int mid = Integer.parseInt(request.getParameter("mid")) ;
					HttpSession session = request.getSession(true) ;
					session.setAttribute("mid", mid);
					url ="Insert.jsp" ;
					break ;
				
				case "/Purchase" :
					PurchaseDetails pDetails = new PurchaseDetails() ;
					pDetails.setCustname(request.getParameter("txtName"));
					pDetails.setMailid(request.getParameter("txtEmail"));
					pDetails.setPhoneno(request.getParameter("txtPhoneNo"));
					String dateStr = request.getParameter("txtPurDate");
					DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd") ;
					pDetails.setPurchaseDate(LocalDate.parse(dateStr, df));
					
					session = request.getSession(false) ;
					
					pDetails.setMobileid((Integer) session.getAttribute("mid"));
					int pid = mobileService.insertPurchaseDetails(pDetails) ;
					request.setAttribute("pDetails", pDetails);
					url="Success.jsp" ;
			}
		} 
		catch (MobileException e) 
		{
			request.setAttribute("error", e.getMessage());
			url = "Error.jsp" ;
		}
		catch (Exception e) 
		{
			request.setAttribute("error", e.getMessage());
			url = "Error.jsp" ;
		}
		
		RequestDispatcher disp = request.getRequestDispatcher(url) ;
		disp.forward(request, response);
		
	}

}

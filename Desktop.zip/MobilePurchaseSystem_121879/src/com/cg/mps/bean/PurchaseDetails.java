package com.cg.mps.bean;

import java.sql.Date;
import java.time.LocalDate;

public class PurchaseDetails
{
	private int purchaseid ;
	private String custname ;
	private String mailid ;
	private String phoneno ;
	private LocalDate purchaseDate ;
	private int mobileid ;
	
	public PurchaseDetails(int purchaseid, String custname, String mailid,
			String phoneno, LocalDate purchaseDate, int mobileid) {
		super();
		this.purchaseid = purchaseid;
		this.custname = custname;
		this.mailid = mailid;
		this.phoneno = phoneno;
		this.purchaseDate = purchaseDate;
		this.mobileid = mobileid;
	}
	
	public PurchaseDetails() {
		// TODO Auto-generated constructor stub
	}

	public int getPurchaseid() {
		return purchaseid;
	}

	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
	}

	public String getCustname() {
		return custname;
	}

	public void setCustname(String custname) {
		this.custname = custname;
	}

	public String getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	public String getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public int getMobileid() {
		return mobileid;
	}

	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}

	@Override
	public String toString() {
		return "PurchaseDetails [purchaseid=" + purchaseid + ", custname="
				+ custname + ", mailid=" + mailid + ", phoneno=" + phoneno
				+ ", purchaseDate=" + purchaseDate + ", mobileid=" + mobileid
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + purchaseid;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PurchaseDetails other = (PurchaseDetails) obj;
		if (purchaseid != other.purchaseid)
			return false;
		return true;
	}
	
	
}

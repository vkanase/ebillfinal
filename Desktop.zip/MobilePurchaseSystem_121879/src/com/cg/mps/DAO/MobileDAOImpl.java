package com.cg.mps.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mps.bean.Mobile;
import com.cg.mps.bean.PurchaseDetails;
import com.cg.mps.exception.MobileException;
import com.cg.mps.util.DBUtil;

public class MobileDAOImpl implements IMobileDAO 
{

	Connection con ;
	@Override
	public List<Mobile> getMobiles() throws MobileException 
	{
		String query = "select * from mobiles" ;
		List<Mobile> mobiles = new ArrayList<>() ;
		try
		{
			
			con = DBUtil.getConnection() ;
			Statement stm = con.createStatement() ;
			ResultSet res = stm.executeQuery(query) ;
			while(res.next())
			{
				Mobile m = new Mobile();
				m.setMobileid(res.getInt("mobileid"));
				m.setMobileName(res.getString("name"));
				m.setPrice(res.getDouble("price"));
				m.setQuantity(res.getInt("quantity"));
				System.out.println(m.getMobileName());
				mobiles.add(m) ;
			}
		}
		catch(SQLException e)
		{
			throw new MobileException("Problem in fetching mobile data ") ;
		}
		return mobiles;
	}

	private int fetchPurchaseId() throws MobileException 
	{
		String seq = "select seq_purchaseid.nextval from dual" ;
		int pid ;
		try 
		{
			con = DBUtil.getConnection() ;
			Statement stm = con.createStatement() ;
			ResultSet res = stm.executeQuery(seq) ;
			res.next() ;
			pid = res.getInt(1) ;
		} 
		catch (SQLException e) 
		{
			throw new MobileException("Problem in fetching purchaseId ") ;
		}
		return pid;
	}
	@Override
	public int insertPurchaseDetails(PurchaseDetails pDetails)	throws MobileException 
	{
		String insertQuery = "insert into purchasedetails values(?,?,?,?,?,?)" ;
		
		try 
		{
			con = DBUtil.getConnection() ;
			pDetails.setPurchaseid(fetchPurchaseId());
			
			PreparedStatement pstm = con.prepareStatement(insertQuery) ;
			pstm.setInt(1, pDetails.getPurchaseid());
			pstm.setString(2, pDetails.getCustname());
			pstm.setString(3, pDetails.getMailid());
			pstm.setString(4, pDetails.getPhoneno());
			pstm.setDate(5, Date.valueOf(pDetails.getPurchaseDate()));
			pstm.setInt(6, pDetails.getMobileid());
			pstm.executeUpdate() ;
		}
		catch (SQLException e) 
		{
			throw new MobileException("Problem in inserting purchase Details ") ;
		}
		return pDetails.getPurchaseid();
	}

}

package com.cg.mps.DAO;

import java.util.List;

import com.cg.mps.bean.Mobile;
import com.cg.mps.bean.PurchaseDetails;
import com.cg.mps.exception.MobileException;

public interface IMobileDAO 
{
	List<Mobile> getMobiles() throws MobileException ;
	int insertPurchaseDetails(PurchaseDetails pDetails) throws MobileException ;
}

package com.cg.mps.service;

import java.util.List;

import com.cg.mps.bean.Mobile;
import com.cg.mps.bean.PurchaseDetails;
import com.cg.mps.exception.MobileException;

public interface IMobileService 
{
	List<Mobile> getMobiles() throws MobileException ;
	int insertPurchaseDetails(PurchaseDetails pDetails) throws MobileException ; 
}

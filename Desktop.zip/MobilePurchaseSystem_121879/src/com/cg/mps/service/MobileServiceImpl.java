package com.cg.mps.service;

import java.util.List;

import com.cg.mps.DAO.IMobileDAO;
import com.cg.mps.DAO.MobileDAOImpl;
import com.cg.mps.bean.Mobile;
import com.cg.mps.bean.PurchaseDetails;
import com.cg.mps.exception.MobileException;

public class MobileServiceImpl implements IMobileService 
{
	IMobileDAO mobileDAO ;	
	public MobileServiceImpl() 
	{
		mobileDAO = new MobileDAOImpl() ;
	}
	@Override
	public List<Mobile> getMobiles() throws MobileException 
	{
		return mobileDAO.getMobiles();
	}

	@Override
	public int insertPurchaseDetails(PurchaseDetails pDetails) throws MobileException 
	{
		return mobileDAO.insertPurchaseDetails(pDetails);
	}

}

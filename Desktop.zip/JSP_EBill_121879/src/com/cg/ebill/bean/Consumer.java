package com.cg.ebill.bean;

public class Consumer 
{
	private int consumerNumber ;
	private String consumerName ;
	private String address ;
	
	public Consumer(int consumerNumber, String consumerName, String address) {
		super();
		this.consumerNumber = consumerNumber;
		this.consumerName = consumerName;
		this.address = address;
	}
	
	public Consumer() 
	{
		super();
	}

	public int getConsumerNumber() {
		return consumerNumber;
	}

	public void setConsumerNumber(int consumerNumber) {
		this.consumerNumber = consumerNumber;
	}

	public String getConsumerName() {
		return consumerName;
	}

	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Consumer [consumerNumber=" + consumerNumber + ", consumerName="
				+ consumerName + ", address=" + address + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + consumerNumber;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Consumer other = (Consumer) obj;
		if (consumerNumber != other.consumerNumber)
			return false;
		return true;
	}
	
	
}

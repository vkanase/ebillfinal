package com.cg.ebill.bean;

import java.sql.Date;

public class BillDetails 
{
	private int billNumber ;
	private int consumerNumber ;
	private double currentReading ;
	private double unitConsumed ;
	private double netAmount ;
	private Date billDate ;
	
	public BillDetails(int billNumber, int consumerNumber,
			double currentReading, double unitConsumed, double netAmount,
			Date billDate) {
		super();
		this.billNumber = billNumber;
		this.consumerNumber = consumerNumber;
		this.currentReading = currentReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.billDate = billDate;
	}
	
	public BillDetails() 
	{
		super() ;
	}

	public int getBillNumber() {
		return billNumber;
	}

	public void setBillNumber(int billNumber) {
		this.billNumber = billNumber;
	}

	public int getConsumerNumber() {
		return consumerNumber;
	}

	public void setConsumerNumber(int consumerNumber) {
		this.consumerNumber = consumerNumber;
	}

	public double getCurrentReading() {
		return currentReading;
	}

	public void setCurrentReading(double currentReading) {
		this.currentReading = currentReading;
	}

	public double getUnitConsumed() {
		return unitConsumed;
	}

	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}

	public double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}

	public Date getBillDate() {
		return billDate;
	}

	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}

	@Override
	public String toString() {
		return "BillDetails [billNumber=" + billNumber + ", consumerNumber="
				+ consumerNumber + ", currentReading=" + currentReading
				+ ", unitConsumed=" + unitConsumed + ", netAmount=" + netAmount
				+ ", billDate=" + billDate + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + billNumber;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BillDetails other = (BillDetails) obj;
		if (billNumber != other.billNumber)
			return false;
		return true;
	}
	
	
}

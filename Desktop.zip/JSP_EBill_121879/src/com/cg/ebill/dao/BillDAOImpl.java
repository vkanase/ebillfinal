package com.cg.ebill.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.ebill.bean.BillDetails;
import com.cg.ebill.bean.Consumer;
import com.cg.ebill.exception.CustomerException;
import com.cg.ebill.util.DBUtil;

public class BillDAOImpl implements IBillDAO {

	Connection con ;
	Statement stm ;
	PreparedStatement pstm ;
	ResultSet res ;
	@Override
	public List<Consumer> getConsumers() throws CustomerException 
	{
		List<Consumer> consumers = new ArrayList<Consumer>() ;
		try
		{
			con = DBUtil.getConnection() ;
		    stm = con.createStatement() ;
			ResultSet res = stm.executeQuery("select * from consumers") ;
			while(res.next())
			{
				Consumer consumer = new Consumer() ;
				consumer.setConsumerNumber(res.getInt("consumer_num"));
				consumer.setConsumerName(res.getString("consumer_name"));
				consumer.setAddress(res.getString("address"));
				consumers.add(consumer);
			}
		}
		catch(SQLException e)
		{
			throw new CustomerException("Problem in fectching all details ") ;
			
		}
		return consumers;
	}

	@Override
	public boolean isCustomerExist(int consumer_num) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Consumer getConsumerDetails(int consumer_num) 
	{
		Consumer consumer = null ;
		try
		{
			con = DBUtil.getConnection() ;
			pstm = con.prepareStatement("select * from consumers where consumer_num=?");
			pstm.setInt(1, consumer_num);
			res = pstm.executeQuery() ;
			res.next() ;
			consumer = new Consumer() ;
			consumer.setConsumerNumber(res.getInt("consumer_num"));
			consumer.setConsumerName(res.getString("consumer_name"));
			consumer.setAddress(res.getString("address"));
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				res.close();
				pstm.close();
				con.close();
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
			
		}
		return consumer;
	}

	@Override
	public BillDetails addBillDetails(BillDetails billDetails) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BillDetails> getBillDetails(int consumer_num)
	{
		List<BillDetails> billList = new ArrayList<BillDetails>();
		BillDetails billDetails = null ;
		try
		{
			con = DBUtil.getConnection();
			pstm = con.prepareStatement("select * from billDetails where consumer_num = ?") ;
			pstm.setInt(1, consumer_num);
			res = pstm.executeQuery();
			while(res.next())
			{
				billDetails = new BillDetails() ;
				billDetails.setBillNumber(res.getInt("bill_num"));
				billDetails.setConsumerNumber(res.getInt("consumer_num"));
				billDetails.setCurrentReading(res.getDouble("cur_reading"));
				billDetails.setUnitConsumed(res.getDouble("unitconsumed"));
				billDetails.setNetAmount(res.getDouble("netamount"));
				billDetails.setBillDate(res.getDate("bill_date"));
				billList.add(billDetails) ;
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			
		}
		return  billList;
	}

	
}

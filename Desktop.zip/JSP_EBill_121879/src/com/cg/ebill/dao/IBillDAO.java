package com.cg.ebill.dao;

import java.util.List;

import com.cg.ebill.bean.BillDetails;
import com.cg.ebill.bean.Consumer;
import com.cg.ebill.exception.CustomerException;

public interface IBillDAO 
{
	List<Consumer> getConsumers() throws CustomerException;
	public boolean isCustomerExist( int consumer_num ) ;
	public Consumer getConsumerDetails( int consumer_num ) ;
	public BillDetails addBillDetails( BillDetails billDetails ) ;
	public List<BillDetails> getBillDetails(int consumer_num) ;
}

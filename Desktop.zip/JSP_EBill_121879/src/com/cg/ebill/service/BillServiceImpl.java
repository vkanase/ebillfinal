package com.cg.ebill.service;

import java.util.List;

import com.cg.ebill.bean.BillDetails;
import com.cg.ebill.bean.Consumer;
import com.cg.ebill.dao.BillDAOImpl;
import com.cg.ebill.dao.IBillDAO;
import com.cg.ebill.exception.CustomerException;

public class BillServiceImpl implements IBillService 
{

	IBillDAO billDAO ;
	
	public BillServiceImpl() 
	{
		billDAO = new BillDAOImpl() ;
	}
	@Override
	public List<Consumer> getConsumers() throws CustomerException 
	{
		return billDAO.getConsumers();
	}

	@Override
	public boolean isCustomerExist(int consumer_num) 
	{
		return billDAO.isCustomerExist(consumer_num);
	}

	@Override
	public Consumer getConsumerDetails(int consumer_num) 
	{
		// TODO Auto-generated method stub
		return billDAO.getConsumerDetails(consumer_num);
	}

	@Override
	public BillDetails addBillDetails(BillDetails billDetails) 
	{
		return billDAO.addBillDetails(billDetails);
	}
	@Override
	public List<BillDetails> getBillDetails(int consumer_num) {
		// TODO Auto-generated method stub
		return billDAO.getBillDetails(consumer_num);
	}

}

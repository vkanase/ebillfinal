package com.cg.ebill.controller;

import java.io.IOException;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder.In;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ebill.bean.BillDetails;
import com.cg.ebill.bean.Consumer;
import com.cg.ebill.service.BillServiceImpl;
import com.cg.ebill.service.IBillService;

@WebServlet(urlPatterns ={"/ListConsumer","/SearchConsumer","/GetConsumer","/ShowBill","/generateBill"})
public class EBillController extends HttpServlet
{
	IBillService billService ;
	private static final long serialVersionUID = 1L;

    public EBillController() 
    {
        super();
        billService = new BillServiceImpl() ;
       
    }

	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	public void destroy() 
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String path = request.getServletPath() ;
		String url = "";
		System.out.println(path);
		
		switch (path) 
		{
			case "/ListConsumer":
				List<Consumer> consumers = billService.getConsumers() ;
				request.setAttribute("consumerList", consumers);
				url = "ListConsumer.jsp" ;
				break;
			
			case "/SearchConsumer":
				url ="Show_ConsumerList.jsp" ;
				break;

			case "/GetConsumer" :
				String conNum = request.getParameter("txtConNum");
				int consumerNumber = Integer.parseInt(conNum) ;
				Consumer consumer = billService.getConsumerDetails(consumerNumber) ;
				request.setAttribute("consumerInfo", consumer);
				url="ConsumerInfo.jsp" ;
				System.out.println(consumer);
				break;
				
			case "/ShowBill" :
				int cons_num = Integer.parseInt(request.getParameter("conNum")) ;
				List<BillDetails> billDetails = billService.getBillDetails(cons_num);
				request.setAttribute("connum", cons_num);
				request.setAttribute("billInfo", billDetails);
				System.out.println(billDetails);
				url = "Show_Bills.jsp";
				break ;
			
			case "/generateBill" :
				int con_num = Integer.parseInt(request.getParameter("con_num") );
				System.out.println(con_num);
				request.setAttribute("conNum", con_num);
				url="insertBillDetails.jsp" ;
				break;
				
			case "/Calculate" :
				int cons_number = Integer.parseInt(request.getParameter("txtCNum"));
				double lmr = Double.parseDouble(request.getParameter("txtLMR")) ;
				double cmr = Double.parseDouble(request.getParameter("txtCMR"));
				
				if(cmr>lmr)
				{
					double unitconsumed = cmr - lmr ;
				}
				break;
			default:
				break;
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(url) ;
		rd.forward(request, response);
	}

}
